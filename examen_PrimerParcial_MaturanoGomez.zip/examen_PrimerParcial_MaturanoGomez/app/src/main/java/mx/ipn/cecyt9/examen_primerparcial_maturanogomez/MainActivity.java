package mx.ipn.cecyt9.examen_primerparcial_maturanogomez;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    String usuarioObtenido = "";
    String passwordObtenido = "";
    String usuario = "Gabriela";
    String password = "123";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText tv = (EditText) findViewById(R.id.editText);
        EditText tv2 = (EditText) findViewById(R.id.editText2);
        usuarioObtenido = tv.getText().toString();
        passwordObtenido = tv2.getText().toString();

    }

    public void validacion(View view){

        if(usuario.equals(usuarioObtenido) && password.equals(passwordObtenido)){
            Toast toast1 = Toast.makeText(getApplicationContext(),
                    "Usuario correcto", Toast. LENGTH_SHORT);
            toast1.show();
        }
        else{
            Toast toast2 = Toast.makeText(getApplicationContext(),
                    "Usuario incorrecto", Toast. LENGTH_SHORT);
            toast2.show();
        }
    }
}
